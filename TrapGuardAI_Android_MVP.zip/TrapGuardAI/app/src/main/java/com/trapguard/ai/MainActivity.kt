package com.trapguard.ai

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Ink = Color(0xFF0B1220)
private val Panel = Color(0xFF151F30)
private val Green = Color(0xFF39D98A)
private val Muted = Color(0xFF9BA9BC)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { TrapGuardApp() }
    }
}

data class Finding(val title: String, val detail: String, val points: Int)

data class ScanResult(val score: Int, val level: String, val findings: List<Finding>, val advice: List<String>)

@Composable
fun TrapGuardApp() {
    var message by remember { mutableStateOf("") }
    var result by remember { mutableStateOf<ScanResult?>(null) }

    MaterialTheme(colorScheme = darkColorScheme(
        background = Ink, surface = Panel, primary = Green,
        onBackground = Color.White, onSurface = Color.White
    )) {
        Surface(Modifier.fillMaxSize(), color = Ink) {
            Column(
                Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(18.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Surface(shape = RoundedCornerShape(15.dp), color = Green.copy(alpha = .13f)) {
                        Icon(Icons.Filled.Shield, null, tint = Green, modifier = Modifier.padding(12.dp).size(30.dp))
                    }
                    Spacer(Modifier.width(12.dp))
                    Column {
                        Text("TRAPGUARD AI", fontSize = 23.sp, fontWeight = FontWeight.Black, color = Color.White)
                        Text("DETECT  •  ANALYSE  •  PROTECT", fontSize = 10.sp, color = Green, fontWeight = FontWeight.Bold)
                    }
                }

                Column(verticalArrangement = Arrangement.spacedBy(7.dp)) {
                    Text("Stay one step ahead.", fontSize = 27.sp, fontWeight = FontWeight.Bold)
                    Text("Check a suspicious message for common scam, coercion and blackmail warning signs.", color = Muted, fontSize = 14.sp)
                }

                Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(20.dp)) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Text("MESSAGE ANALYSER", color = Green, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        OutlinedTextField(
                            value = message,
                            onValueChange = { message = it; result = null },
                            modifier = Modifier.fillMaxWidth().heightIn(min = 150.dp),
                            placeholder = { Text("Paste the message or conversation here…", color = Muted) },
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = Green, unfocusedBorderColor = Muted.copy(alpha = .5f),
                                focusedTextColor = Color.White, unfocusedTextColor = Color.White,
                                cursorColor = Green
                            )
                        )
                        Button(
                            onClick = { result = analyseMessage(message) },
                            enabled = message.isNotBlank(),
                            modifier = Modifier.fillMaxWidth(),
                            colors = ButtonDefaults.buttonColors(containerColor = Green, contentColor = Ink),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Icon(Icons.Filled.Security, null)
                            Spacer(Modifier.width(8.dp))
                            Text("ANALYSE MESSAGE", fontWeight = FontWeight.Bold)
                        }
                        Text("Prototype analysis runs on this device. Your text is not uploaded.", color = Muted, fontSize = 11.sp)
                    }
                }

                result?.let { ScanReport(it) }

                Card(colors = CardDefaults.cardColors(containerColor = Panel.copy(alpha = .8f)), shape = RoundedCornerShape(16.dp)) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                        Text("IMPORTANT", color = Green, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        Text("A risk score is a warning aid, not proof that a person is deceptive or guilty. Context matters. Do not send money, intimate images, passwords or verification codes to someone pressuring you.", color = Muted, fontSize = 12.sp)
                    }
                }
                Text("TRAPGUARD AI  •  MVP 0.1.0", color = Muted, fontSize = 10.sp, modifier = Modifier.align(Alignment.CenterHorizontally))
            }
        }
    }
}

@Composable
fun ScanReport(result: ScanResult) {
    val color = when (result.level) {
        "HIGH" -> Color(0xFFFF6464)
        "MEDIUM" -> Color(0xFFFFC857)
        else -> Green
    }
    Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(20.dp)) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text("ANALYSIS RESULT", color = Green, fontWeight = FontWeight.Bold, fontSize = 12.sp)
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                Column {
                    Text("${result.level} RISK", color = color, fontWeight = FontWeight.Black, fontSize = 22.sp)
                    Text("Prototype indicator score", color = Muted, fontSize = 11.sp)
                }
                Text("${result.score}/100", color = color, fontWeight = FontWeight.Black, fontSize = 25.sp)
            }
            LinearProgressIndicator(
                progress = { result.score / 100f },
                modifier = Modifier.fillMaxWidth().height(8.dp),
                color = color,
                trackColor = Color(0xFF344154)
            )
            Text("Signals found", fontWeight = FontWeight.Bold)
            if (result.findings.isEmpty()) {
                Text("No listed warning patterns were detected. This does not prove the message or sender is safe.", color = Muted, fontSize = 13.sp)
            } else {
                result.findings.forEach { finding ->
                    Column(verticalArrangement = Arrangement.spacedBy(3.dp)) {
                        Text("• ${finding.title}", color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                        Text(finding.detail, color = Muted, fontSize = 12.sp)
                    }
                }
            }
            Text("Suggested next steps", fontWeight = FontWeight.Bold)
            result.advice.forEach { Text("✓  $it", color = Muted, fontSize = 12.sp) }
        }
    }
}

fun analyseMessage(raw: String): ScanResult {
    val text = raw.lowercase()
    data class Rule(val terms: List<String>, val title: String, val detail: String, val points: Int)
    val rules = listOf(
        Rule(listOf("send money", "transfer money", "urgent payment", "gift card", "upi", "bank details"), "Money request", "The message may be asking for money or financial information.", 28),
        Rule(listOf("don't tell anyone", "keep this secret", "secret between us", "delete this chat"), "Secrecy pressure", "Pressure to keep a relationship or request secret can be a manipulation warning sign.", 18),
        Rule(listOf("send nudes", "send me pictures", "intimate photo", "private video"), "Intimate-image pressure", "A request for intimate content can create privacy and exploitation risks.", 25),
        Rule(listOf("i will leak", "i'll leak", "share your photos", "expose you", "viral", "blackmail"), "Threat or blackmail language", "Threats to expose private material are serious warning signs.", 35),
        Rule(listOf("otp", "verification code", "password", "pin number", "cvv"), "Credential or code request", "Never share passwords, OTPs, PINs or card security codes.", 30),
        Rule(listOf("invest now", "guaranteed return", "double your money", "crypto profit"), "Unrealistic financial promise", "Guaranteed or unusually high returns are commonly used in scams.", 22),
        Rule(listOf("i love you", "soulmate", "marry me"), "Fast emotional commitment", "Strong affection very early can warrant caution when combined with other pressure tactics.", 8)
    )
    val found = rules.filter { rule -> rule.terms.any { text.contains(it) } }
        .map { Finding(it.title, it.detail, it.points) }
    val rawScore = found.sumOf { it.points }.coerceAtMost(100)
    val level = when {
        rawScore >= 55 -> "HIGH"
        rawScore >= 25 -> "MEDIUM"
        else -> "LOW"
    }
    val advice = buildList {
        add("Pause before replying; do not act under pressure.")
        if (found.any { it.title.contains("Money") || it.title.contains("financial") || it.title.contains("promise") }) add("Do not transfer money or share banking details.")
        if (found.any { it.title.contains("Intimate") || it.title.contains("Threat") }) add("Do not send more intimate content; preserve evidence of threats.")
        if (found.any { it.title.contains("Credential") }) add("Never share OTPs, passwords, PINs or verification codes.")
        add("Verify claims independently using a trusted channel.")
        add("If threatened, save screenshots and seek help from local authorities or a trusted person.")
    }.distinct()
    return ScanResult(rawScore, level, found, advice)
}
